import joblib
import numpy as np

# Load model and scaler
model = joblib.load("insta_model.pkl")
scaler = joblib.load("insta_scaler.pkl")

def predict_fake_account(features):
    """
    features = [followers_count, following_count, posts_count,
                verified, account_age_days, has_profile_pic, bio_length]
    """
    scaled_features = scaler.transform([features])
    prediction = model.predict(scaled_features)[0]
    return "Fake Account" if prediction == 1 else "Genuine Account"
