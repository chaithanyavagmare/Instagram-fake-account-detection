from predict_bot import predict_fake_account

# Example input: realistic Instagram account
example_account = [2500, 300, 120, 1, 1460, 1, 80]
result = predict_fake_account(example_account)

print("Prediction:", result)
