from flask import Flask, render_template, request
from predict_bot import predict_fake_account

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def home():
    if request.method == 'POST':
        inputs = [
            int(request.form['followers']),
            int(request.form['following']),
            int(request.form['posts']),
            int(request.form['verified']),
            int(request.form['age']),
            int(request.form['profile_pic']),
            int(request.form['bio_length'])
        ]
        result = predict_fake_account(inputs)
        return render_template('index.html', prediction=result)
    return render_template('index.html')

if __name__ == "__main__":
    app.run(debug=True)
