import pandas as pd
import numpy as np

def generate_instagram_data(n_samples=100):
    np.random.seed(42)
    data = {
        "followers_count": np.random.randint(0, 10000, n_samples),
        "following_count": np.random.randint(0, 5000, n_samples),
        "posts_count": np.random.randint(0, 1000, n_samples),
        "verified": np.random.choice([0, 1], n_samples, p=[0.9, 0.1]),
        "account_age_days": np.random.randint(30, 4000, n_samples),
        "has_profile_pic": np.random.choice([0, 1], n_samples, p=[0.2, 0.8]),
        "bio_length": np.random.randint(0, 200, n_samples),
        "bot": np.random.choice([0, 1], n_samples, p=[0.7, 0.3])
    }

    df = pd.DataFrame(data)
    df.to_csv("instagram_bots_data.csv", index=False)
    print("✅ Dataset saved as instagram_bots_data.csv")

if __name__ == "__main__":
    generate_instagram_data()
